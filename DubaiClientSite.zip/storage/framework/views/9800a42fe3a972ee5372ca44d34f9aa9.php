<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<a class="da-product-preview-card" href="<?php echo e(route($product['route'])); ?>">
    <img src="<?php echo e(asset($product['gallery'][0])); ?>" alt="<?php echo e($product['title']); ?>" loading="lazy">
    <span class="da-product-preview-category"><?php echo e($product['category']); ?></span>
    <strong><?php echo e($product['title']); ?></strong>
    <div class="da-product-preview-badges">
        <?php $__currentLoopData = array_slice($product['badges'] ?? [], 0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><b><?php echo e($badge); ?></b><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <span>⌖ <?php echo e($product['location']); ?></span>
    </div>
    <em>Sample from AED <?php echo e(number_format($product['booking']['base_price'])); ?></em>
</a>
<?php /**PATH D:\DubaiClientSite\resources\views/components/desert-adventures/product-preview-card.blade.php ENDPATH**/ ?>
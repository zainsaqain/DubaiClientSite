<?php $__env->startSection('title', 'Desert Safaris | Waheed Murad Tourism'); ?>

<?php $__env->startSection('content'); ?>
    <?php ($adventures = config('desert-safaris.adventures', [])); ?>
    <section class="da-category-hero da-container">
        <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['items' => [['label' => 'Home', 'url' => route('home')], ['label' => 'Desert Adventures', 'url' => route('desert-adventures')], ['label' => 'Desert Safaris']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['label' => 'Home', 'url' => route('home')], ['label' => 'Desert Adventures', 'url' => route('desert-adventures')], ['label' => 'Desert Safaris']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
        <h1>Desert Safaris</h1><p>Discover the wonders of the Dubai desert on an unforgettable desert safari. Travel across rolling sand dunes in a comfortable 4x4, spot fascinating wildlife, and enjoy expertly prepared food under the stars in a traditional Bedouin setting.</p>
        <div class="da-feature-list"><article><span>▱</span><div><b>Transfers from Dubai</b><small>Shared or Private</small></div></article><article><span>⌁</span><div><b>Dune Drive</b><small>Wildlife Spotting</small></div></article><article><span>♧</span><div><b>Desert Activities</b><small>Camel Rides &amp; Sandboarding</small></div></article><article><span>☕</span><div><b>Food &amp; Refreshments</b><small>BBQs, Breakfast &amp; More</small></div></article></div>
    </section>
    <section class="da-container da-catalogue da-category-catalogue" aria-label="Desert safari adventures"><aside class="da-filter-sidebar" data-filters><div class="da-filter-heading"><strong>Filter by</strong><button type="button" data-filter-toggle aria-expanded="false">Filters <b>⌄</b></button></div><div class="da-filter-groups" data-filter-groups><details open><summary>Category <b>⌃</b></summary><p class="da-filter-parent">Desert Adventures</p><label><input type="checkbox" value="safari" data-filter="category"> Desert Safaris (<?php echo e(count($adventures)); ?>)</label></details><details open><summary>Location <b>⌃</b></summary><label><input type="checkbox" value="dubai" data-filter="location"> Dubai (<?php echo e(count($adventures)); ?>)</label></details><details><summary>Time <b>⌄</b></summary><label><input type="checkbox" value="morning" data-filter="time"> Morning</label><label><input type="checkbox" value="evening" data-filter="time"> Evening</label></details><details><summary>Price <b>⌄</b></summary><label><input type="radio" name="price" value="500" data-price-filter> Under AED 500</label><label><input type="radio" name="price" value="99999" data-price-filter> AED 500+</label></details></div></aside><div class="da-results"><div class="da-results-top"><strong><span data-product-count><?php echo e(count($adventures)); ?></span> products found</strong><label>Sort by <select data-sort><option value="popular">Most Popular</option><option value="low">Price: Low to High</option><option value="high">Price: High to Low</option><option value="az">Name: A–Z</option></select></label></div><div class="da-adventure-list" data-adventure-list><?php $__currentLoopData = $adventures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adventure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if (isset($component)) { $__componentOriginal54f8b0467838b8736df86e182bf60f4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal54f8b0467838b8736df86e182bf60f4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.desert-adventures.adventure-card','data' => ['adventure' => $adventure]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('desert-adventures.adventure-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['adventure' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($adventure)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal54f8b0467838b8736df86e182bf60f4f)): ?>
<?php $attributes = $__attributesOriginal54f8b0467838b8736df86e182bf60f4f; ?>
<?php unset($__attributesOriginal54f8b0467838b8736df86e182bf60f4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal54f8b0467838b8736df86e182bf60f4f)): ?>
<?php $component = $__componentOriginal54f8b0467838b8736df86e182bf60f4f; ?>
<?php unset($__componentOriginal54f8b0467838b8736df86e182bf60f4f); ?>
<?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><p class="da-no-results" data-no-results hidden>No safaris match your filters. <button type="button" data-clear-filters>Clear filters</button></p><div class="da-show-more-wrap da-category-count"><span data-showing-count>Showing <?php echo e(count($adventures)); ?> of <?php echo e(count($adventures)); ?> products</span></div></div></section>

    <section class="da-desert-story da-container da-category-story">
        <h2 class="da-section-title">Desert Safaris with <span>Arabian Adventures</span></h2>
        <article class="da-story-row"><img src="<?php echo e(asset('images/desert-safari.png')); ?>" alt="Desert safari guides in the dunes" loading="lazy"><div><h3>An award-winning experience</h3><p>Our desert safari page introduces a memorable way to experience Dubai’s dunes, wildlife and hospitality. Friendly guides bring local knowledge to every stage of the journey, from the drive through the reserve to time spent in a Bedouin-inspired setting.</p></div></article>
        <article class="da-story-row da-story-row--reverse"><div><h3>The Dubai Desert Conservation Reserve</h3><p>These safari experiences are designed around the remarkable desert landscape outside Dubai. The reserve setting offers broad red dunes, native wildlife and a calm escape from the city, all within an easy drive of downtown.</p></div><img src="<?php echo e(asset('images/desert-oasis-morning.png')); ?>" alt="Desert wildlife landscape" loading="lazy"></article>
        <article class="da-story-row"><img src="<?php echo e(asset('images/desert-dune-drive.png')); ?>" alt="Desert travellers looking across the dunes" loading="lazy"><div><h3>Eco-friendly and sustainable practices</h3><p>Thoughtful travel starts with respecting the desert. The future live experience can share verified sustainability, wildlife and operational information here while retaining this clear, welcoming page structure.</p></div></article>
    </section>

    <section class="da-container da-faq da-category-faq"><h2 class="da-section-title">Frequently asked <span>questions</span></h2><div class="da-faq-list"><details><summary>What do you wear on a desert safari?<b>+</b></summary><p>Choose lightweight, breathable clothing, comfortable closed shoes and sun protection. Carry a light layer for cooler desert evenings.</p></details><details><summary>Where is a Dubai desert safari?<b>+</b></summary><p>These sample itineraries are designed around Dubai’s desert landscape, outside the city and reached by a planned transfer.</p></details><details><summary>How long is a desert safari?<b>+</b></summary><p>Duration varies by the selected experience. Each product page shows an example duration until live schedules are connected.</p></details><details><summary>What is included in a desert safari in Dubai?<b>+</b></summary><p>Inclusions depend on the selected option. The product detail page presents a clear sample itinerary and feature list for each experience.</p></details><details><summary>What is the price of a desert safari?<b>+</b></summary><p>All prices shown in this frontend are sample figures, clearly labelled until live pricing is connected.</p></details></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.desert-adventures', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DubaiClientSite\resources\views\pages\desert-safaris.blade.php ENDPATH**/ ?>
<header class="site-header" id="top">
    <div class="color-ribbon" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span><span></span></div>
    <div class="utility-bar"><div class="header-container utility-content"><p>Curated journeys across Dubai and the UAE</p><div class="utility-links"><a href="<?php echo e(url('/')); ?>#contact">Travel support</a><span aria-hidden="true"></span><a href="<?php echo e(url('/')); ?>#booking">Manage booking</a></div></div></div>
    <div class="main-header"><div class="header-container brand-row">
        <a class="brand" href="<?php echo e(url('/')); ?>" aria-label="Waheed Murad Tourism home"><span class="brand-mark"><img src="<?php echo e(asset('images/waheed-murad-tourism-logo.jpeg')); ?>" alt="Waheed Murad Tourism"></span><span class="brand-copy"><strong>Waheed Murad</strong><small>Tourism</small></span></a>
        <div class="desktop-tools">
            <a class="quick-link" href="https://wa.me/971500000000" target="_blank" rel="noopener noreferrer" aria-label="Open WhatsApp chat with local travel expert"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.5 11.7a8.4 8.4 0 0 1-12.4 7.4L3.5 20.5l1.5-4.3A8.4 8.4 0 1 1 20.5 11.7Z"/><path d="M8.6 7.9c.2-.5.4-.5.7-.5h.5c.2 0 .4.1.5.4l.8 1.9c.1.2.1.4 0 .6l-.5.7c-.1.2-.1.3 0 .5.5 1 1.3 1.8 2.4 2.3.2.1.4.1.5 0l.8-.9c.2-.2.4-.2.6-.1l1.8.8c.3.1.4.3.4.5 0 .4-.2 1.2-.7 1.5-.3.2-.7.4-1.2.4-.7 0-1.5-.2-2.7-.8a10.3 10.3 0 0 1-4.3-4.1c-.8-1.2-1-2.1-1-2.8 0-.4.2-.8.4-1.1Z"/></svg><span><small>Talk to a local expert</small><b>WhatsApp us</b></span></a>
            <button class="header-search" type="button" aria-label="Search experiences"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.5"/><path d="m16 16 4.4 4.4"/></svg><span>Search experiences</span></button>
            <a class="plan-trip" href="#contact">Plan your trip <span aria-hidden="true">→</span></a>
        </div>
        <div class="mobile-quick-actions" aria-label="Quick actions"><a class="mobile-icon-link" href="#wishlist" aria-label="Wishlist, 0 items"><span class="action-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.8 4.9a5.3 5.3 0 0 0-7.5 0L12 6.2l-1.3-1.3a5.3 5.3 0 0 0-7.5 0L3.2 12.4 12 21l8.8-8.6a5.3 5.3 0 0 0 0-7.5Z"/></svg><b>0</b></span></a><a class="mobile-icon-link" href="#cart" aria-label="Cart, 0 items"><span class="action-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.5 8.5h13l-.7 11H6.2l-.7-11Z"/><path d="M9 9V6.5a3 3 0 0 1 6 0V9"/></svg><b>0</b></span></a></div>
        <button class="menu-toggle" type="button" aria-controls="mobile-navigation" aria-expanded="false"><span class="sr-only">Open navigation</span><i></i><i></i><i></i></button>
    </div></div>
    <nav class="primary-navigation" aria-label="Main navigation"><div class="header-container navigation-row"><div class="nav-links"><div class="nav-item has-mega-menu <?php echo e(request()->routeIs('desert-adventures', 'desert-safaris', 'morning-desert-adventure', 'evening-desert-safari', 'desert-experiences', 'exclusive-desert-experience', 'camel-ride', 'dune-buggies-category', 'dune-buggy-adventure') ? 'is-active' : ''); ?>" data-mega-menu><button class="nav-trigger" type="button" aria-haspopup="true" aria-expanded="false" aria-controls="desert-adventures-mega-menu">Desert Adventures<svg viewBox="0 0 16 16" aria-hidden="true"><path d="m4 6 4 4 4-4"/></svg></button><?php if (isset($component)) { $__componentOriginal689fd981861e996c55bb8b71809fb75f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal689fd981861e996c55bb8b71809fb75f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.desert-adventures-mega-menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.desert-adventures-mega-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal689fd981861e996c55bb8b71809fb75f)): ?>
<?php $attributes = $__attributesOriginal689fd981861e996c55bb8b71809fb75f; ?>
<?php unset($__attributesOriginal689fd981861e996c55bb8b71809fb75f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal689fd981861e996c55bb8b71809fb75f)): ?>
<?php $component = $__componentOriginal689fd981861e996c55bb8b71809fb75f; ?>
<?php unset($__componentOriginal689fd981861e996c55bb8b71809fb75f); ?>
<?php endif; ?></div><a href="<?php echo e(url('/')); ?>#attractions">Attractions</a><a class="<?php echo e(request()->routeIs('dune-buggies', 'dune-buggies-category', 'dune-buggy-adventure') ? 'is-active' : ''); ?>" href="<?php echo e(route('dune-buggies-category')); ?>">Dune Buggies</a><a href="<?php echo e(url('/')); ?>#city-tours">City Tours</a><a href="<?php echo e(url('/')); ?>#cruise-boat-tours">Cruise and Boat Tours</a><a href="<?php echo e(url('/')); ?>#waterparks-theme-parks">Waterparks &amp; Theme Parks</a><a href="<?php echo e(url('/')); ?>#transfers">Transfers</a><a href="<?php echo e(url('/')); ?>#why-us">Why us</a></div><div class="account-links"><?php if(auth()->guard()->check()): ?><a href="<?php echo e(url('/dashboard')); ?>" class="account-link"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/></svg><span>My account</span></a><?php else: ?><a href="<?php echo e(route('login')); ?>" class="account-link"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M4.5 21a7.5 0 0 1 15 0"/></svg><span>Sign in</span></a><?php endif; ?><a class="header-action" href="#wishlist"><span class="action-icon">♡<b>0</b></span><span>Wishlist</span></a><a class="header-action" href="#cart"><span class="action-icon">♧<b>0</b></span><span>Cart</span></a></div></div></nav>
    <div class="mobile-navigation" id="mobile-navigation" hidden aria-hidden="true"><button class="mobile-menu-scrim" type="button" aria-label="Close navigation"></button><aside class="mobile-menu-drawer" aria-label="Mobile navigation"><div class="mobile-menu-bar"><span>Explore Dubai</span><button class="mobile-menu-close" type="button" aria-label="Close navigation">×</button></div><nav class="mobile-menu-main" aria-label="Mobile main navigation"><button class="mobile-menu-item mobile-menu-trigger" type="button" aria-controls="mobile-desert-menu" aria-expanded="false"><span class="mobile-nav-icon icon-dunes" aria-hidden="true">⌁</span><span>Desert Adventures</span><i aria-hidden="true">›</i></button><a class="mobile-menu-item" href="<?php echo e(url('/')); ?>#attractions"><span class="mobile-nav-icon icon-attractions" aria-hidden="true">✦</span><span>Attractions</span></a><a class="mobile-menu-item" href="<?php echo e(route('dune-buggies-category')); ?>"><span class="mobile-nav-icon icon-sports" aria-hidden="true">◉</span><span>Dune Buggies</span></a><a class="mobile-menu-item" href="<?php echo e(url('/')); ?>#city-tours"><span class="mobile-nav-icon icon-city" aria-hidden="true">▥</span><span>City Tours</span></a><a class="mobile-menu-item" href="<?php echo e(url('/')); ?>#cruise-boat-tours"><span class="mobile-nav-icon icon-cruise" aria-hidden="true">⌇</span><span>Cruise and Boat Tours</span></a><a class="mobile-menu-item" href="<?php echo e(url('/')); ?>#waterparks-theme-parks"><span class="mobile-nav-icon icon-parks" aria-hidden="true">♧</span><span>Waterparks &amp; Theme Parks</span></a><a class="mobile-menu-item" href="<?php echo e(url('/')); ?>#transfers"><span class="mobile-nav-icon icon-transfers" aria-hidden="true">↗</span><span>Transfers</span></a><a class="mobile-menu-item" href="<?php echo e(url('/')); ?>#why-us"><span class="mobile-nav-icon icon-why" aria-hidden="true">♥</span><span>Why us</span></a></nav><div class="mobile-menu-actions"><a href="<?php echo e(route('login')); ?>">Sign in / Create account</a><a class="mobile-plan-trip" href="#contact">Plan your trip <span aria-hidden="true">→</span></a></div><?php if (isset($component)) { $__componentOriginal689fd981861e996c55bb8b71809fb75f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal689fd981861e996c55bb8b71809fb75f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.desert-adventures-mega-menu','data' => ['mobile' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.desert-adventures-mega-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['mobile' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal689fd981861e996c55bb8b71809fb75f)): ?>
<?php $attributes = $__attributesOriginal689fd981861e996c55bb8b71809fb75f; ?>
<?php unset($__attributesOriginal689fd981861e996c55bb8b71809fb75f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal689fd981861e996c55bb8b71809fb75f)): ?>
<?php $component = $__componentOriginal689fd981861e996c55bb8b71809fb75f; ?>
<?php unset($__componentOriginal689fd981861e996c55bb8b71809fb75f); ?>
<?php endif; ?></aside></div>
</header>
<?php /**PATH D:\DubaiClientSite\resources\views\components\site\header.blade.php ENDPATH**/ ?>
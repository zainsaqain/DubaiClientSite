<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['products' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['products' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(collect($products)->isNotEmpty()): ?>
    <section class="da-product-collection da-related" data-related-carousel aria-label="Other experiences you might like">
        <div class="da-product-collection-heading"><h2>Other <span>experiences</span> you might like</h2><div><button type="button" data-carousel-previous aria-label="Show previous experiences">←</button><button type="button" data-carousel-next aria-label="Show next experiences">→</button></div></div>
        <div class="da-product-preview-track" data-carousel-track tabindex="0">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if (isset($component)) { $__componentOriginal21f32d601e936e6b8b3c85789c523daf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21f32d601e936e6b8b3c85789c523daf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.desert-adventures.product-preview-card','data' => ['product' => $related]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('desert-adventures.product-preview-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($related)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21f32d601e936e6b8b3c85789c523daf)): ?>
<?php $attributes = $__attributesOriginal21f32d601e936e6b8b3c85789c523daf; ?>
<?php unset($__attributesOriginal21f32d601e936e6b8b3c85789c523daf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21f32d601e936e6b8b3c85789c523daf)): ?>
<?php $component = $__componentOriginal21f32d601e936e6b8b3c85789c523daf; ?>
<?php unset($__componentOriginal21f32d601e936e6b8b3c85789c523daf); ?>
<?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH D:\DubaiClientSite\resources\views\components\desert-adventures\related-experiences.blade.php ENDPATH**/ ?>
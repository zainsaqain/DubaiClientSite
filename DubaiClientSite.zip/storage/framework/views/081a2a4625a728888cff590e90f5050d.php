<section class="mega-menu why-us-mega-menu" id="why-us-mega-menu" aria-label="Why choose Waheed Murad Tourism menu">
    <div class="why-us-mega-menu-grid">
        <section class="mega-categories why-us-categories" aria-label="Explore more about us">
            <a class="mega-category" href="<?php echo e(url('/')); ?>#why-us"><img class="category-orb" src="<?php echo e(asset('images/camel-desert-journey.png')); ?>" alt=""><span><b>Sustainable Tourism</b></span></a>
            <a class="mega-category" href="<?php echo e(url('/')); ?>#city-tours"><img class="category-orb" src="<?php echo e(asset('images/global-village-dubai.png')); ?>" alt=""><span><b>Culture</b></span></a>
            <a class="mega-category" href="<?php echo e(url('/')); ?>#experiences"><img class="category-orb" src="<?php echo e(asset('images/desert-oasis-morning.png')); ?>" alt=""><span><b>Nature</b></span></a>
            <a class="mega-category" href="<?php echo e(url('/')); ?>#attractions"><img class="category-orb" src="<?php echo e(asset('images/dubai-attractions.png')); ?>" alt=""><span><b>Innovation</b></span></a>
            <a class="mega-category" href="<?php echo e(url('/')); ?>#contact"><img class="category-orb" src="<?php echo e(asset('images/helicopter-tour-dubai.png')); ?>" alt=""><span><b>Travel Agent Partners</b></span></a>
        </section>

        <section class="mega-picks why-us-blogs" aria-labelledby="why-us-blogs-title">
            <p class="mega-eyebrow" id="why-us-blogs-title">Top Blogs of the month</p>
            <a href="<?php echo e(url('/')); ?>#experiences">Morning vs Evening Desert Safari <span aria-hidden="true">→</span></a>
            <a href="<?php echo e(url('/')); ?>#city-tours">Date night in Dubai <span aria-hidden="true">→</span></a>
            <a href="<?php echo e(url('/')); ?>#why-us">Native plants of Dubai <span aria-hidden="true">→</span></a>
            <a href="<?php echo e(url('/')); ?>#experiences">An introduction to the DDCR <span aria-hidden="true">→</span></a>
            <a href="<?php echo e(url('/')); ?>#contact">How to greet in Arabic <span aria-hidden="true">→</span></a>
            <a class="mega-view-all" href="<?php echo e(route('blogs')); ?>">View all blogs <span aria-hidden="true">→</span></a>
        </section>

    </div>
</section>
<?php /**PATH E:\DubaiClientSite\DubaiClientSite\resources\views\components\site\why-us-mega-menu.blade.php ENDPATH**/ ?>
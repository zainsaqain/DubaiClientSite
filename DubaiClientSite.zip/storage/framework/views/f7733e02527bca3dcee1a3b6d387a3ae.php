<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['mobile' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['mobile' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $menu = config('desert-navigation');
    $urlFor = static function (array $item): string {
        return isset($item['route']) && \Illuminate\Support\Facades\Route::has($item['route'])
            ? route($item['route'])
            : url($item['url'] ?? '/desert-adventures');
    };
?>

<?php if($mobile): ?>
    <section class="mobile-submenu-panel" id="mobile-desert-menu" aria-label="Desert Adventures submenu" aria-hidden="true">
        <div class="mobile-menu-bar mobile-submenu-bar">
            <button class="mobile-menu-back" type="button"><span aria-hidden="true">‹</span> Back</button>
            <button class="mobile-menu-close" type="button" aria-label="Close navigation">×</button>
        </div>
        <div class="mobile-submenu-content">
            <p class="mobile-submenu-eyebrow">Discover the desert</p>
            <h2>Desert Adventures</h2>

            <?php $__currentLoopData = $menu['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="mobile-submenu-category" href="<?php echo e($urlFor($category)); ?>">
                    <img class="category-orb" src="<?php echo e(asset($category['image'])); ?>" alt="">
                    <span><b><?php echo e($category['label']); ?></b><small><?php echo e($category['description']); ?></small></span>
                    <i aria-hidden="true">›</i>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="mobile-top-picks">
                <p>Top picks of the month</p>
                <?php $__currentLoopData = $menu['top_picks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pick): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($urlFor($pick)); ?>"><?php echo e($pick['label']); ?> <span aria-hidden="true">→</span></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php else: ?>
    <section class="mega-menu" id="desert-adventures-mega-menu" aria-label="Desert Adventures menu">
        <div class="mega-menu-grid">
            <section class="mega-categories" aria-labelledby="desert-categories-title">
                <p class="mega-eyebrow" id="desert-categories-title">Categories</p>
                <?php $__currentLoopData = $menu['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="mega-category" href="<?php echo e($urlFor($category)); ?>">
                        <img class="category-orb" src="<?php echo e(asset($category['image'])); ?>" alt="">
                        <span><b><?php echo e($category['label']); ?></b><small><?php echo e($category['description']); ?></small></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>

            <section class="mega-picks" aria-labelledby="desert-picks-title">
                <p class="mega-eyebrow" id="desert-picks-title">Top picks of the month</p>
                <?php $__currentLoopData = $menu['top_picks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pick): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($urlFor($pick)); ?>"><?php echo e($pick['label']); ?> <span aria-hidden="true">→</span></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH E:\DubaiClientSite\DubaiClientSite\resources\views/components/site/desert-adventures-mega-menu.blade.php ENDPATH**/ ?>
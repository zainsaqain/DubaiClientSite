<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['products' => [], 'currentProductKey']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['products' => [], 'currentProductKey']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section class="da-product-collection da-recently-viewed" data-recently-viewed data-current-product="<?php echo e($currentProductKey); ?>" aria-label="Recently viewed experiences">
    <div class="da-product-collection-heading"><h2>Recently <span>viewed</span></h2></div>
    <p class="da-recently-viewed-empty" data-recently-viewed-empty>Open another experience to see it here.</p>
    <div class="da-product-preview-track" data-recently-viewed-list>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $recentProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key !== $currentProductKey): ?><div data-recent-product="<?php echo e($key); ?>" hidden><?php if (isset($component)) { $__componentOriginal21f32d601e936e6b8b3c85789c523daf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21f32d601e936e6b8b3c85789c523daf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.desert-adventures.product-preview-card','data' => ['product' => $recentProduct]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('desert-adventures.product-preview-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($recentProduct)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21f32d601e936e6b8b3c85789c523daf)): ?>
<?php $attributes = $__attributesOriginal21f32d601e936e6b8b3c85789c523daf; ?>
<?php unset($__attributesOriginal21f32d601e936e6b8b3c85789c523daf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21f32d601e936e6b8b3c85789c523daf)): ?>
<?php $component = $__componentOriginal21f32d601e936e6b8b3c85789c523daf; ?>
<?php unset($__componentOriginal21f32d601e936e6b8b3c85789c523daf); ?>
<?php endif; ?></div><?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php /**PATH D:\DubaiClientSite\resources\views/components/desert-adventures/recently-viewed.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Desert Experiences | Waheed Murad Tourism'); ?>

<?php $__env->startSection('content'); ?>
    <?php ($adventures = config('desert-experiences.adventures', [])); ?>
    <section class="da-category-hero da-container">
        <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['items' => [['label' => 'Home', 'url' => route('home')], ['label' => 'Desert Adventures', 'url' => route('desert-adventures')], ['label' => 'Desert Experiences']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['label' => 'Home', 'url' => route('home')], ['label' => 'Desert Adventures', 'url' => route('desert-adventures')], ['label' => 'Desert Experiences']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
        <h1>Desert Experiences</h1><p>Slow down and take in the remarkable scenery, culture and hospitality of the Dubai desert. Our curated desert experiences pair authentic activities with memorable dining, private moments and warm Arabian welcome.</p>
        <div class="da-feature-list"><article><span>◌</span><div><b>Private Experiences</b><small>Made around you</small></div></article><article><span>⌁</span><div><b>Desert Dining</b><small>Under the stars</small></div></article><article><span>♧</span><div><b>Local Culture</b><small>Heritage &amp; stories</small></div></article><article><span>☼</span><div><b>Beautiful Settings</b><small>Morning or evening</small></div></article></div>
    </section>
    <section class="da-container da-catalogue da-category-catalogue" aria-label="Desert experiences"><aside class="da-filter-sidebar" data-filters><div class="da-filter-heading"><strong>Filter by</strong><button type="button" data-filter-toggle aria-expanded="false">Filters <b>⌄</b></button></div><div class="da-filter-groups" data-filter-groups><details open><summary>Category <b>⌃</b></summary><p class="da-filter-parent">Desert Adventures</p><label><input type="checkbox" value="experience" data-filter="category"> Desert Experiences (<?php echo e(count($adventures)); ?>)</label></details><details open><summary>Location <b>⌃</b></summary><label><input type="checkbox" value="dubai" data-filter="location"> Dubai</label><label><input type="checkbox" value="lisaili" data-filter="location"> Lisaili</label></details><details><summary>Time <b>⌄</b></summary><label><input type="checkbox" value="morning" data-filter="time"> Morning</label><label><input type="checkbox" value="evening" data-filter="time"> Evening</label></details></div></aside><div class="da-results"><div class="da-results-top"><strong><span data-product-count><?php echo e(count($adventures)); ?></span> products found</strong><label>Sort by <select data-sort><option value="popular">Most Popular</option><option value="low">Price: Low to High</option><option value="high">Price: High to Low</option><option value="az">Name: A–Z</option></select></label></div><div class="da-adventure-list" data-adventure-list><?php $__currentLoopData = $adventures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adventure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if (isset($component)) { $__componentOriginal54f8b0467838b8736df86e182bf60f4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal54f8b0467838b8736df86e182bf60f4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.desert-adventures.adventure-card','data' => ['adventure' => $adventure]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('desert-adventures.adventure-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['adventure' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($adventure)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal54f8b0467838b8736df86e182bf60f4f)): ?>
<?php $attributes = $__attributesOriginal54f8b0467838b8736df86e182bf60f4f; ?>
<?php unset($__attributesOriginal54f8b0467838b8736df86e182bf60f4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal54f8b0467838b8736df86e182bf60f4f)): ?>
<?php $component = $__componentOriginal54f8b0467838b8736df86e182bf60f4f; ?>
<?php unset($__componentOriginal54f8b0467838b8736df86e182bf60f4f); ?>
<?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><p class="da-no-results" data-no-results hidden>No experiences match your filters. <button type="button" data-clear-filters>Clear filters</button></p><div class="da-show-more-wrap da-category-count"><span data-showing-count>Showing <?php echo e(count($adventures)); ?> of <?php echo e(count($adventures)); ?> products</span></div></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.desert-adventures', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\DubaiClientSite\DubaiClientSite\resources\views\pages\desert-experiences.blade.php ENDPATH**/ ?>
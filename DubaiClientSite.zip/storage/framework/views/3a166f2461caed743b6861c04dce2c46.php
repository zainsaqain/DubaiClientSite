<?php $__env->startSection('title', 'Sports Events | Waheed Murad Tourism'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $events = [
            [
                'title' => 'Dubai Championship Golf Day',
                'image' => 'images/sports-golf-dubai.png',
                'description' => 'A polished day on the fairway with championship atmosphere, skyline views and premium hospitality.',
                'location' => 'Dubai',
                'price' => 'PKR 100,028',
                'tag' => 'Golf',
            ],
            [
                'title' => 'Abu Dhabi Grand Prix Weekend',
                'image' => 'images/sports-events-dubai.png',
                'description' => 'Feel the energy of race weekend with a seamless UAE experience built around speed, spectacle and excitement.',
                'location' => 'Abu Dhabi',
                'price' => 'PKR 299,622',
                'tag' => 'Motorsport',
            ],
            [
                'title' => 'Dubai Sevens Rugby Experience',
                'image' => 'images/sports-rugby-dubai.png',
                'description' => 'A high-energy stadium day with world-class rugby, big-match atmosphere and unforgettable Dubai evenings.',
                'location' => 'Dubai',
                'price' => 'PKR 115,417',
                'tag' => 'Rugby',
            ],
            [
                'title' => 'Topgolf Dubai Evening',
                'image' => 'images/sports-golf-dubai.png',
                'description' => 'Bring your group together for golf, great food and city views in one of Dubai’s favourite social spots.',
                'location' => 'Dubai',
                'price' => 'PKR 13,850',
                'tag' => 'Leisure sport',
            ],
        ];
    ?>

    <section class="sports-events-page da-container">
        <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['items' => [['label' => 'Home', 'url' => route('home')], ['label' => 'Sports Events']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['label' => 'Home', 'url' => route('home')], ['label' => 'Sports Events']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>

        <div class="sports-events-heading">
            <div><span class="sports-events-eyebrow">LIVE THE MOMENT</span><h1>Sports <span>Events</span></h1><p>From championship golf to race weekends, discover standout sports experiences across the UAE.</p></div>
            <a href="<?php echo e(url('/')); ?>#booking" class="sports-events-plan">Plan your sports day <span aria-hidden="true">→</span></a>
        </div>

        <div class="sports-events-layout">
            <aside class="sports-events-filter" aria-label="Sports events filters">
                <div class="sports-filter-heading"><strong>Find your event</strong><span>4 experiences</span></div>
                <details open><summary>Category <b>⌃</b></summary><label><input type="checkbox" checked> Sports Events</label></details>
                <details open><summary>Location <b>⌃</b></summary><label><input type="checkbox"> Dubai</label><label><input type="checkbox"> Abu Dhabi</label></details>
                <details open><summary>Experience type <b>⌃</b></summary><label><input type="checkbox"> Motorsport</label><label><input type="checkbox"> Golf</label><label><input type="checkbox"> Stadium events</label></details>
                <div class="sports-filter-help"><span aria-hidden="true">✦</span><p>Need help choosing?<br><a href="https://wa.me/971500000000" target="_blank" rel="noopener noreferrer">Ask our local team</a></p></div>
            </aside>

            <div class="sports-events-results">
                <div class="sports-results-bar"><strong><span><?php echo e(count($events)); ?></span> sports events to explore</strong><label>Sort by <select><option>Most popular</option><option>Price: Low to high</option><option>Price: High to low</option></select></label></div>
                <div class="sports-event-list">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="sports-event-card">
                            <img src="<?php echo e(asset($event['image'])); ?>" alt="<?php echo e($event['title']); ?>" loading="lazy">
                            <div class="sports-event-copy"><span><?php echo e($event['tag']); ?></span><h2><?php echo e($event['title']); ?></h2><p><?php echo e($event['description']); ?></p><small>⌖ <?php echo e($event['location']); ?></small></div>
                            <div class="sports-event-action"><small>From</small><strong><?php echo e($event['price']); ?></strong><a href="<?php echo e(url('/')); ?>#booking">Book now <span aria-hidden="true">→</span></a></div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <p class="sports-events-note">You’ve explored all <?php echo e(count($events)); ?> sports events.</p>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.desert-adventures', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\DubaiClientSite\DubaiClientSite\resources\views\pages\sports-events.blade.php ENDPATH**/ ?>
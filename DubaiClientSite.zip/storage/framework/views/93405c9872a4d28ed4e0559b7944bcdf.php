<?php $__env->startSection('title', 'School Trips | Waheed Murad Tourism'); ?>

<?php $__env->startSection('content'); ?>
    <?php ($adventures = config('school-trips.adventures', [])); ?>

    <section class="da-category-hero da-container">
        <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['items' => [['label' => 'Home', 'url' => route('home')], ['label' => 'Desert Adventures', 'url' => route('desert-adventures')], ['label' => 'School Trips']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['label' => 'Home', 'url' => route('home')], ['label' => 'Desert Adventures', 'url' => route('desert-adventures')], ['label' => 'School Trips']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
        <h1>School Trips</h1>
        <p>Explore sample school-trip ideas designed around the desert’s wildlife, heritage and landscapes. Each page is a static preview so a future booking flow can add live group availability, educational options and safeguarding details without changing the frontend structure.</p>
        <div class="da-feature-list">
            <article><span>✦</span><div><b>Learning moments</b><small>Desert heritage &amp; nature</small></div></article>
            <article><span>◌</span><div><b>Group-friendly</b><small>Sample daytime options</small></div></article>
            <article><span>▱</span><div><b>Guided visits</b><small>Static itinerary previews</small></div></article>
            <article><span>♧</span><div><b>Flexible planning</b><small>Future group configuration</small></div></article>
        </div>
    </section>

    <section class="da-container da-catalogue da-category-catalogue" aria-label="School trip adventures">
        <aside class="da-filter-sidebar" data-filters>
            <div class="da-filter-heading"><strong>Filter by</strong><button type="button" data-filter-toggle aria-expanded="false">Filters <b>⌄</b></button></div>
            <div class="da-filter-groups" data-filter-groups>
                <details open><summary>Category <b>⌃</b></summary><p class="da-filter-parent">Desert Adventures</p><label><input type="checkbox" value="school" data-filter="category"> School Trips (<?php echo e(count($adventures)); ?>)</label></details>
                <details open><summary>Location <b>⌃</b></summary><label><input type="checkbox" value="dubai" data-filter="location"> Dubai</label><label><input type="checkbox" value="lisaili" data-filter="location"> Lisaili</label></details>
                <details><summary>Time <b>⌄</b></summary><label><input type="checkbox" value="morning" data-filter="time"> Morning</label><label><input type="checkbox" value="evening" data-filter="time"> Evening</label></details>
                <details><summary>Price <b>⌄</b></summary><label><input type="radio" name="price" value="1000" data-price-filter> Sample price under AED 1,000</label><label><input type="radio" name="price" value="99999" data-price-filter> Sample price AED 1,000+</label></details>
            </div>
        </aside>
        <div class="da-results">
            <div class="da-results-top"><strong><span data-product-count><?php echo e(count($adventures)); ?></span> products found</strong><label>Sort by <select data-sort><option value="popular">Most Popular</option><option value="low">Price: Low to High</option><option value="high">Price: High to Low</option><option value="az">Name: A–Z</option></select></label></div>
            <div class="da-adventure-list" data-adventure-list><?php $__currentLoopData = $adventures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adventure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if (isset($component)) { $__componentOriginal54f8b0467838b8736df86e182bf60f4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal54f8b0467838b8736df86e182bf60f4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.desert-adventures.adventure-card','data' => ['adventure' => $adventure]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('desert-adventures.adventure-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['adventure' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($adventure)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal54f8b0467838b8736df86e182bf60f4f)): ?>
<?php $attributes = $__attributesOriginal54f8b0467838b8736df86e182bf60f4f; ?>
<?php unset($__attributesOriginal54f8b0467838b8736df86e182bf60f4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal54f8b0467838b8736df86e182bf60f4f)): ?>
<?php $component = $__componentOriginal54f8b0467838b8736df86e182bf60f4f; ?>
<?php unset($__componentOriginal54f8b0467838b8736df86e182bf60f4f); ?>
<?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
            <p class="da-no-results" data-no-results hidden>No school trips match your filters. <button type="button" data-clear-filters>Clear filters</button></p>
            <div class="da-show-more-wrap da-category-count"><span data-showing-count>Showing <?php echo e(count($adventures)); ?> of <?php echo e(count($adventures)); ?> products</span></div>
        </div>
    </section>

    <section class="da-desert-story da-container da-category-story">
        <h2 class="da-section-title">Why learn with <span>us</span></h2>
        <article class="da-story-row"><img src="<?php echo e(asset('images/desert-safari.png')); ?>" alt="Desert landscape for a school-trip preview" loading="lazy"><div><h3>Desert heritage</h3><p>This static section demonstrates where future curriculum links, learning goals and teacher resources can be introduced without altering the category layout.</p></div></article>
        <article class="da-story-row da-story-row--reverse"><div><h3>Guided group planning</h3><p>Future group bookings can add confirmed transport, access requirements and supervision details while retaining the current visual presentation.</p></div><img src="<?php echo e(asset('images/desert-oasis-morning.png')); ?>" alt="Morning desert landscape" loading="lazy"></article>
    </section>

    <section class="da-container da-faq da-category-faq"><h2 class="da-section-title">School Trips: Frequently asked <span>questions</span></h2><div class="da-faq-list"><details><summary>Can a school trip be customised?<b>+</b></summary><p>Yes, a future booking system can collect group needs and build an appropriate itinerary. This frontend is only a sample preview.</p></details><details><summary>Are prices live?<b>+</b></summary><p>No. Every displayed price is sample data for layout and interaction testing only.</p></details><details><summary>How are safety and supervision handled?<b>+</b></summary><p>Final safety, transport and supervision arrangements must be confirmed through the future live booking process.</p></details></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.desert-adventures', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DubaiClientSite\resources\views\pages\school-trips.blade.php ENDPATH**/ ?>
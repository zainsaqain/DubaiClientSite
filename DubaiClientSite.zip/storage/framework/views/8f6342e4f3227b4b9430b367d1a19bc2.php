<?php $__env->startSection('title', 'Waterparks & Theme Parks | Waheed Murad Tourism'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $parks = [
            ['title' => 'Dubai Parks and Resorts', 'image' => 'images/dubai-attractions.png', 'tag' => 'Theme park', 'description' => 'A full day of rides, stories and family fun across Dubai’s favourite entertainment parks.', 'price' => 'PKR 22,699'],
            ['title' => 'Atlantis Aquaventure', 'image' => 'images/water-theme-parks-dubai.png', 'tag' => 'Waterpark', 'description' => 'Dive into slides, splash zones and ocean-inspired thrills at one of Dubai’s most iconic waterparks.', 'price' => 'PKR 31,932'],
            ['title' => 'IMG Worlds of Adventure', 'image' => 'images/global-village-dubai.png', 'tag' => 'Indoor adventure', 'description' => 'Step into an air-conditioned world of big rides, favourite characters and all-day entertainment.', 'price' => 'PKR 28,085'],
            ['title' => 'Ski Dubai Snow Park', 'image' => 'images/hero-dubai-aquarium.png', 'tag' => 'Indoor snow', 'description' => 'Swap the sunshine for snowy slopes, winter activities and memorable family moments.', 'price' => 'PKR 19,236'],
            ['title' => 'Wild Wadi Waterpark', 'image' => 'images/water-theme-parks-dubai.png', 'tag' => 'Waterpark', 'description' => 'Cool off with exciting slides, wave pools and spectacular views close to Burj Al Arab.', 'price' => 'PKR 19,929'],
        ];
    ?>

    <section class="sports-events-page waterparks-page da-container">
        <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['items' => [['label' => 'Home', 'url' => route('home')], ['label' => 'Waterparks & Theme Parks']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['label' => 'Home', 'url' => route('home')], ['label' => 'Waterparks & Theme Parks']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>

        <div class="sports-events-heading waterparks-heading">
            <div><span class="sports-events-eyebrow">FAMILY FUN IN DUBAI</span><h1>Waterparks &amp; <span>Theme Parks</span></h1><p>Make every day in Dubai more memorable with splash-filled adventures, thrilling rides and attractions for every age.</p></div>
            <a href="<?php echo e(url('/')); ?>#booking" class="sports-events-plan">Plan a family day <span aria-hidden="true">→</span></a>
        </div>

        <div class="waterparks-highlights" aria-label="Waterparks highlights"><span><b>☼</b>Outdoor water fun</span><span><b>★</b>Thrill rides</span><span><b>♧</b>Family favourites</span><span><b>◷</b>Easy booking</span></div>

        <div class="sports-events-layout">
            <aside class="sports-events-filter" aria-label="Waterparks filters">
                <div class="sports-filter-heading"><strong>Find your day out</strong><span><?php echo e(count($parks)); ?> experiences</span></div>
                <details open><summary>Category <b>⌃</b></summary><label><input type="checkbox" checked> Waterparks &amp; Theme Parks</label></details>
                <details open><summary>Location <b>⌃</b></summary><label><input type="checkbox"> Dubai</label></details>
                <details open><summary>Experience type <b>⌃</b></summary><label><input type="checkbox"> Waterparks</label><label><input type="checkbox"> Theme parks</label><label><input type="checkbox"> Family tickets</label></details>
                <div class="sports-filter-help"><span aria-hidden="true">✦</span><p>Planning with children?<br><a href="https://wa.me/971500000000" target="_blank" rel="noopener noreferrer">Ask our local team</a></p></div>
            </aside>

            <div class="sports-events-results">
                <div class="sports-results-bar"><strong><span><?php echo e(count($parks)); ?></span> experiences to explore</strong><label>Sort by <select><option>Most popular</option><option>Price: Low to high</option><option>Price: High to low</option></select></label></div>
                <div class="sports-event-list">
                    <?php $__currentLoopData = $parks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $park): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="sports-event-card waterpark-card">
                            <img src="<?php echo e(asset($park['image'])); ?>" alt="<?php echo e($park['title']); ?>" loading="lazy">
                            <div class="sports-event-copy"><span><?php echo e($park['tag']); ?></span><h2><?php echo e($park['title']); ?></h2><p><?php echo e($park['description']); ?></p><small>⌖ Dubai</small></div>
                            <div class="sports-event-action"><small>From</small><strong><?php echo e($park['price']); ?></strong><a href="<?php echo e(url('/')); ?>#booking">Book now <span aria-hidden="true">→</span></a></div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <p class="sports-events-note">You’ve explored all <?php echo e(count($parks)); ?> park experiences.</p>
            </div>
        </div>

        <section class="waterparks-callout"><div><span>MAKE A SPLASH</span><h2>A Dubai day out the whole family will remember.</h2><p>From fast slides to amazing worlds, our local team makes it simple to choose the right experience for your group.</p></div><a href="<?php echo e(url('/')); ?>#booking">Start planning <span aria-hidden="true">→</span></a></section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.desert-adventures', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\DubaiClientSite\DubaiClientSite\resources\views\pages\waterparks-theme-parks.blade.php ENDPATH**/ ?>
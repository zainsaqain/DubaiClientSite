<?php $__env->startSection('body-class', 'da-site'); ?>

<?php $__env->startPush('page-assets'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/desert-adventures/page.css', 'resources/js/desert-adventures/page.js']); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DubaiClientSite\resources\views/layouts/desert-adventures.blade.php ENDPATH**/ ?>
<?php ($product = config("adventure-products.{$productKey}")); ?>



<?php $__env->startSection('title', $product['title'].' | Waheed Murad Tourism'); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalf718cfda215dee6acefca840784273aa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf718cfda215dee6acefca840784273aa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.desert-adventures.product-detail','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('desert-adventures.product-detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf718cfda215dee6acefca840784273aa)): ?>
<?php $attributes = $__attributesOriginalf718cfda215dee6acefca840784273aa; ?>
<?php unset($__attributesOriginalf718cfda215dee6acefca840784273aa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf718cfda215dee6acefca840784273aa)): ?>
<?php $component = $__componentOriginalf718cfda215dee6acefca840784273aa; ?>
<?php unset($__componentOriginalf718cfda215dee6acefca840784273aa); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.desert-adventures', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DubaiClientSite\resources\views\pages\adventure-product-detail.blade.php ENDPATH**/ ?>
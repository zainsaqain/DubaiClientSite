<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $products = config('adventure-products');
    $relatedProducts = collect($product['related'] ?? [])
        ->map(static fn (string $key) => $products[$key] ?? null)
        ->filter();
    $mainImage = $product['gallery'][0];
    $mainAlt = $product['gallery_alt'][0] ?? $product['title'];
?>

<section class="da-product-page da-container" data-product-detail>
    <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['items' => [
        ['label' => 'Home', 'url' => route('home')],
        ['label' => 'Desert Adventures', 'url' => route('desert-adventures')],
        ['label' => $product['category'], 'url' => route($product['category_route'])],
        ['label' => $product['title']],
    ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        ['label' => 'Home', 'url' => route('home')],
        ['label' => 'Desert Adventures', 'url' => route('desert-adventures')],
        ['label' => $product['category'], 'url' => route($product['category_route'])],
        ['label' => $product['title']],
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>

    <div class="da-product-heading">
        <div>
            <span><?php echo e($product['category']); ?> · <?php echo e($product['location']); ?></span>
            <h1><?php echo e($product['title']); ?></h1>
            <p>By Waheed Murad Tourism</p>
        </div>
        <?php if(count($product['badges'])): ?>
            <div class="da-product-awards" aria-label="Experience badges">
                <?php $__currentLoopData = $product['badges']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span><?php echo e($badge); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="da-product-gallery" data-product-gallery>
        <figure class="da-gallery-main"><img src="<?php echo e(asset($mainImage)); ?>" alt="<?php echo e($mainAlt); ?>" loading="eager" data-gallery-main><figcaption>Experience preview</figcaption></figure>
        <?php $__currentLoopData = array_slice($product['gallery'], 1, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <figure><img src="<?php echo e(asset($image)); ?>" alt="<?php echo e($product['gallery_alt'][$index + 1] ?? $product['title']); ?>" loading="lazy"><?php if($loop->last): ?><button type="button" data-gallery-show-all>View photos</button><?php endif; ?></figure>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="da-gallery-thumbnails" aria-label="Product image gallery">
        <?php $__currentLoopData = $product['gallery']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" data-gallery-thumbnail data-image="<?php echo e(asset($image)); ?>" data-alt="<?php echo e($product['gallery_alt'][$index] ?? $product['title']); ?>" aria-label="Show photo <?php echo e($index + 1); ?> of <?php echo e($product['title']); ?>" <?php if($loop->first): ?> aria-pressed="true" <?php else: ?> aria-pressed="false" <?php endif; ?>><img src="<?php echo e(asset($image)); ?>" alt=""></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="da-product-layout">
        <div class="da-product-content">
            <p class="da-pickup-notice">● <?php echo e($product['pickup']); ?></p>
            <div class="da-product-features">
                <?php $__currentLoopData = $product['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$icon, $title, $detail]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span><?php echo e($icon); ?> <b><?php echo e($title); ?></b><small><?php echo e($detail); ?></small></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <section class="da-product-section"><h2>About</h2><p><?php echo e($product['about']); ?></p><ul><li>Duration: <?php echo e($product['duration']); ?></li><li>Language: English</li></ul></section>
            <details class="da-product-disclosure"><summary>Full description <b>⌄</b></summary><p><?php echo e($product['description']); ?></p></details>

            <section class="da-itinerary"><h2>Experience itinerary</h2><ol><?php $__currentLoopData = $product['itinerary']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$title, $description, $duration]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><b><?php echo e($title); ?></b><p><?php echo e($description); ?></p><small>◷ <?php echo e($duration); ?></small></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ol></section>
            <details class="da-product-disclosure"><summary>Highlights <b>⌄</b></summary><p>This is a static experience preview. Highlight details shown here are illustrative and should be confirmed before any future booking.</p></details>
            <details class="da-product-disclosure"><summary>Know before you go <b>⌄</b></summary><p><?php echo e($product['know_before']); ?></p></details>
            <details class="da-product-disclosure"><summary>Age policy <b>⌄</b></summary><p><?php echo e($product['age_policy']); ?></p></details>
            <details class="da-product-disclosure"><summary>Cancellation policy <b>⌄</b></summary><p><?php echo e($product['cancellation']); ?></p></details>

            <div class="da-video-preview"><img src="<?php echo e(asset($product['video_image'])); ?>" alt="<?php echo e($product['title']); ?> video preview" loading="lazy"><button type="button" aria-label="Preview <?php echo e($product['title']); ?> video" data-video-preview>▶</button><strong><?php echo e($product['title']); ?> preview</strong><span data-video-status aria-live="polite"></span></div>
        </div>

        <aside class="da-booking-card" data-booking-card>
            <p>Sample from <strong data-booking-total>AED <?php echo e(number_format($product['booking']['base_price'])); ?></strong><small>Example price only — not live</small></p>
            <h2>Select date and travellers</h2>
            <label>Date<input type="date" data-booking-date></label>
            <div class="da-traveller-grid">
                <div><span>Adults</span><div class="da-quantity-control"><button type="button" data-quantity-action="decrease" data-quantity="adults" aria-label="Decrease adults">−</button><output data-quantity-output="adults">1</output><button type="button" data-quantity-action="increase" data-quantity="adults" aria-label="Increase adults">+</button></div></div>
                <div><span>Children</span><div class="da-quantity-control"><button type="button" data-quantity-action="decrease" data-quantity="children" aria-label="Decrease children">−</button><output data-quantity-output="children">0</output><button type="button" data-quantity-action="increase" data-quantity="children" aria-label="Increase children">+</button></div></div>
            </div>
            <label>Choose your sample service<select data-booking-service><?php $__currentLoopData = $product['booking']['services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($service['price']); ?>"><?php echo e($service['label']); ?> — AED <?php echo e(number_format($service['price'])); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <small>Sample availability and prices only. This interface does not create a booking or payment.</small>
            <button type="button" class="da-check-availability" data-check-availability>Check sample availability <span aria-hidden="true">→</span></button>
            <p class="da-booking-status" data-booking-status aria-live="polite"></p>
        </aside>
    </div>

    <?php if (isset($component)) { $__componentOriginal4852f7b275f6f58733dfbbd05a23e2e0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4852f7b275f6f58733dfbbd05a23e2e0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.desert-adventures.related-experiences','data' => ['products' => $relatedProducts]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('desert-adventures.related-experiences'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($relatedProducts)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4852f7b275f6f58733dfbbd05a23e2e0)): ?>
<?php $attributes = $__attributesOriginal4852f7b275f6f58733dfbbd05a23e2e0; ?>
<?php unset($__attributesOriginal4852f7b275f6f58733dfbbd05a23e2e0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4852f7b275f6f58733dfbbd05a23e2e0)): ?>
<?php $component = $__componentOriginal4852f7b275f6f58733dfbbd05a23e2e0; ?>
<?php unset($__componentOriginal4852f7b275f6f58733dfbbd05a23e2e0); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginald98f81450432b572162c983cb510efa2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald98f81450432b572162c983cb510efa2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.desert-adventures.recently-viewed','data' => ['products' => $products,'currentProductKey' => $product['route']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('desert-adventures.recently-viewed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products),'current-product-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product['route'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald98f81450432b572162c983cb510efa2)): ?>
<?php $attributes = $__attributesOriginald98f81450432b572162c983cb510efa2; ?>
<?php unset($__attributesOriginald98f81450432b572162c983cb510efa2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald98f81450432b572162c983cb510efa2)): ?>
<?php $component = $__componentOriginald98f81450432b572162c983cb510efa2; ?>
<?php unset($__componentOriginald98f81450432b572162c983cb510efa2); ?>
<?php endif; ?>
</section>
<?php /**PATH D:\DubaiClientSite\resources\views\components\desert-adventures\product-detail.blade.php ENDPATH**/ ?>
<footer class="site-footer" id="contact">
    <div class="footer-ribbon" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></div>
    <div class="header-container footer-top">
        <div class="footer-grid">
            <div class="footer-brand-column">
                <a class="footer-brand" href="{{ url('/') }}" aria-label="Waheed Murad Tourism home"><img src="{{ asset('images/waheed-murad-tourism-logo.jpeg') }}" alt="Waheed Murad Tourism"><span><strong>Waheed Murad</strong><small>Tourism</small></span></a>
                <p class="footer-subscribe-copy">Get Dubai ideas, seasonal offers and travel inspiration in your inbox.</p>
                <a class="footer-subscribe-button" href="{{ url('/') }}#booking">Get travel updates <span aria-hidden="true">→</span></a>
                <div class="footer-socials" aria-label="Social media links"><a href="{{ url('/') }}#contact" aria-label="Instagram">ig</a><a href="{{ url('/') }}#contact" aria-label="Facebook">f</a><a href="{{ url('/') }}#contact" aria-label="Trip advisor">ta</a><a href="{{ url('/') }}#contact" aria-label="LinkedIn">in</a></div>
            </div>
            <div class="footer-col"><h4>Contact us</h4><ul class="footer-contact-list"><li><span aria-hidden="true">☎</span><a href="tel:+971500000000">+971 50 000 0000</a></li><li><span aria-hidden="true">◉</span><a href="https://wa.me/971500000000" target="_blank" rel="noopener noreferrer">WhatsApp our travel desk</a></li><li><span aria-hidden="true">✉</span><a href="mailto:hello@waheedmuradtourism.com">hello@waheedmuradtourism.com</a></li><li><span aria-hidden="true">⌖</span><a href="{{ url('/') }}#contact">Downtown Dubai, UAE</a></li></ul></div>
            <div class="footer-col"><h4>Explore Dubai</h4><ul class="footer-links"><li><a href="{{ url('/') }}#desert-safaris">Desert Safaris</a></li><li><a href="{{ url('/') }}#attractions">Attractions</a></li><li><a href="{{ url('/') }}#city-tours">City Tours</a></li><li><a href="{{ url('/') }}#cruise-boat-tours">Cruise &amp; Boat Tours</a></li><li><a href="{{ url('/') }}#waterparks-theme-parks">Water &amp; Theme Parks</a></li></ul></div>
            <div class="footer-col"><h4>Waheed Murad Tourism</h4><ul class="footer-links"><li><a href="{{ url('/') }}#why-us">About us</a></li><li><a href="{{ url('/') }}#why-us">Why Choose Us</a></li><li><a href="{{ url('/') }}#contact">Partner with us</a></li><li><a href="{{ url('/') }}#booking">Plan your trip</a></li><li><a href="{{ url('/') }}#contact">Travel support</a></li></ul></div>
            <div class="footer-col"><h4>Travel information</h4><ul class="footer-links"><li><a href="{{ url('/') }}#contact">Booking guidelines</a></li><li><a href="{{ url('/') }}#contact">Cancellation policy</a></li><li><a href="{{ url('/') }}#contact">Terms &amp; conditions</a></li><li><a href="{{ url('/') }}#contact">Privacy policy</a></li><li><a href="{{ url('/') }}#contact">Frequently asked questions</a></li></ul></div>
        </div>
    </div>
    <div class="header-container footer-bottom"><div class="footer-meta-selects"><span>English ▾</span><span>PKR ▾</span></div><span>&copy; {{ date('Y') }} Waheed Murad Tourism. All rights reserved.</span><span>Dubai, United Arab Emirates</span></div>
</footer>
